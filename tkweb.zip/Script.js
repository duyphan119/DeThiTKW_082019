﻿function validate() {
    var x = document.myForm.txt.value;
    var y = document.myForm.min_price.value;
    var z = document.myForm.max_price.value;
    if (x == "") {
        alert("Nhập Keyword vô!");
        return false;
    }
    if (!y.match(/^[0-9]+$/) || !z.match(/^[0-9]+$/)) {
        alert("Price error");
        return false;
    } else if (eval(y - z) >= 0) {
        alert("Price error");
        return false;
    } else
        alert("Thành công");
    return true;
}