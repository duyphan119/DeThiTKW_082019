﻿//function validateNumber(value) {
//     return (!isNaN(Number(value)) && /^[0-9]+$/.test(value))
// }

function validate() {
    var x = document.myForm.keyw.value;
    var y = document.myForm.price1.value;
    var z = document.myForm.price2.value;
    if (x == "") {
        alert("Nhập Keyword vô!");
        return false;
    }
    if (!y.match(/^[0-9]+$/) || !z.match(/^[0-9]+$/)) {
        alert("Price error");
        return false;
    } else if (eval(y - z) >= 0) {
        alert("Price error");
        return false;
    } else
        alert("Thành công");
    return true;
}